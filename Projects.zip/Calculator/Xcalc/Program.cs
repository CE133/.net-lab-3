﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;

namespace Xcalc
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc cal = new Calc();
            Console.WriteLine("Enter 1st number: ");
            float a = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter 2st number: ");
            float b = float.Parse(Console.ReadLine());
            Console.WriteLine(a + " + " + b + " : " + cal.add(a, b));
            Console.WriteLine(a + " - " + b + " : " + cal.sub(a, b));
            Console.WriteLine(a + " / " + b + " : " + cal.div(a, b));
            Console.WriteLine(a + " * " + b + " : " + cal.mul(a, b));
            Console.ReadLine();
        }
    }
}
