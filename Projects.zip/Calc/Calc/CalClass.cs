﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    public class CalClass
    {
        public int addn(int a, int b)
        {
            return (a + b);
        }
        public int mul(int a, int b)
        {
            return (a * b);
        }
        public int sub(int a, int b)
        {
            return (a - b);
        }
        public int div(int a, int b)
        {
            return (a / b);
        }
    }
}
