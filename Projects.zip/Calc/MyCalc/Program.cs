﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calc;


namespace MyCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());


            CalClass c = new CalClass();
            Console.WriteLine("addition is " + c.addn(a, b));
            Console.WriteLine("multiplication is " + c.mul(a, b));
            Console.WriteLine("subtraction is " + c.sub(a, b));
            Console.WriteLine("division is " + c.div(a, b));
            Console.ReadKey();

        }
    }
}
